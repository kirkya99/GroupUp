package de.rwu.group_up.ui.components.dialogs.image_picker;

import android.net.Uri;

public interface IImagePickerListener {
    void onImagePicked(Uri imageUri);
}
